package com.moldedbits.argus;

/**
 * Overall state of the system.
 */

public enum ArgusState {
    SIGNED_OUT,
    SIGNED_IN
}
