package com.moldedbits.argus.samples.email_social_login.api;

public interface ApiService {
}
