package com.moldedbits.argus.samples.email_social_login;

import com.moldedbits.argus.provider.ForgotPasswordProvider;

public class SimpleForgotPasswordProvider extends ForgotPasswordProvider {
    @Override
    public void sendPasswordResetEmail(final String email) {
    }
}
