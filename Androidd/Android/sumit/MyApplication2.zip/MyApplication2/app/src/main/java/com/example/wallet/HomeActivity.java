package com.example.wallet;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.wallet.Service.Api;
import com.example.wallet.Service.MyRetrofit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class HomeActivity extends AppCompatActivity {
    Button send, receive;
    EditText ed1, ed2;
    Api api;
    String cmobileno;
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        sharedPreferences=getSharedPreferences("MobileNo",MODE_PRIVATE);
        cmobileno = sharedPreferences.getString("cmobileno",null);
        send = findViewById(R.id.send);
        receive = findViewById(R.id.receive);
        ed1 = findViewById(R.id.mobile_no1);
        ed2 = findViewById(R.id.amount);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ed1.getText().toString().isEmpty()) {
                    Toast.makeText(HomeActivity.this, "Enter Mobile No", Toast.LENGTH_SHORT).show();
                } else if (ed2.getText().toString().isEmpty()) {
                    Toast.makeText(HomeActivity.this, "Enter Amount", Toast.LENGTH_SHORT).show();
                } else {
                    Retrofit instance = MyRetrofit.getRetrofit(getString(R.string.IP1));
                    Call<PaymentResponse> call;
                    api = instance.create(Api.class);
                    call = api.paymentsend(cmobileno,ed1.getText().toString(), ed2.getText().toString());
                    call.enqueue(new Callback<PaymentResponse>() {
                        @Override
                        public void onResponse(Call<PaymentResponse> call, Response<PaymentResponse> response) {
                            PaymentResponse pr = response.body();
                            Log.d("Whyred", pr.toString());
                            Log.d("Whyred", pr.getStatus());
                            Intent i = new Intent(HomeActivity.this, SuccessActivity.class);
                            startActivity(i);
                            finish();
                        }

                        @Override
                        public void onFailure(Call<PaymentResponse> call, Throwable t) {
                            Log.d("Whyred", t.toString());
                        }
                    });
                }
            }
        });
    }


}