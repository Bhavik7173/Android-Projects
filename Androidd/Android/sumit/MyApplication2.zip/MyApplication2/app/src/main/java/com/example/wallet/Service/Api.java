package com.example.wallet.Service;

import com.example.wallet.PaymentResponse;
import com.example.wallet.Response.LoginResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface Api {
    @FormUrlEncoded
    @POST("fcm_key.php")
    Call<String> insertKey(@Field("token") String token);

    @FormUrlEncoded
    @POST("paymentsend.php")
    Call<PaymentResponse> paymentsend(@Field("cmob") String cmobileno,@Field("mobile") String ed1, @Field("amount") String ed2);

    @FormUrlEncoded
    @POST("userlogin.php")
    Call<LoginResponse> userLogin(@Field("mobileno") String MN, @Field("password") String password);
}
