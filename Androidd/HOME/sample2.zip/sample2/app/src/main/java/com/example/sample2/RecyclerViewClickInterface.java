package com.example.sample2;

public interface RecyclerViewClickInterface {
    void onItemClick(int position);
}
