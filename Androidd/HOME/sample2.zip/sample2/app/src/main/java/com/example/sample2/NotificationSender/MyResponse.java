package com.example.sample2.NotificationSender;

public class MyResponse {
    public int success;
}
