package com.example.sample2;

public class ProInfo {
    String Qualification,YOP,Experience,Link,Image;

    public String getQualification() {
        return Qualification;
    }

    public void setQualification(String qualification) {
        Qualification = qualification;
    }

    public String getYOP() {
        return YOP;
    }

    public void setYOP(String YOP) {
        this.YOP = YOP;
    }

    public String getExperience() {
        return Experience;
    }

    public void setExperience(String experience) {
        Experience = experience;
    }

    public String getLink() {
        return Link;
    }

    public void setLink(String link) {
        Link = link;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }
}
