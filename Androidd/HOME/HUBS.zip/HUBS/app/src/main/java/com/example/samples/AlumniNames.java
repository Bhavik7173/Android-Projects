package com.example.samples;

public class AlumniNames {
    String Per_Image;
    String Per_Name;
    String Per_Email;
    String Per_ID;

    public String getPer_Image() {
        return this.Per_Image;
    }

    public void setPer_Image(String per_Image) {
        this.Per_Image = per_Image;
    }

    public String getPer_Name() {
        return this.Per_Name;
    }

    public String getPer_Email() {
        return Per_Email;
    }

    public void setPer_Email(String per_Email) {
        Per_Email = per_Email;
    }

    public String getPer_ID() {
        return Per_ID;
    }

    public void setPer_ID(String per_ID) {
        Per_ID = per_ID;
    }

    public void setPer_Name(String per_Name) {
        this.Per_Name = per_Name;
    }

}
