package com.example.samples.NotificationSender;

public class MyResponse {
    public int success;
}
