package com.example.samples;

public interface RecyclerViewClickInterface {
    void onItemClick(int position);
}
