package com.example.hibbub.PersonalProfile2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.hibbub.Acheivement.AcheivementActivity;
import com.example.hibbub.R;
import com.example.hibbub.RetroFile.APIInterface;
import com.example.hibbub.RetroFile.MyRetrofit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class PersonalProfile2 extends AppCompatActivity {
    EditText ed1, ed2, ed3;
    RadioButton btn1, btn2;

    APIInterface apiInterface;
    Retrofit retrofit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_profile2);
        ed1 = findViewById(R.id.interest);
        ed2 = findViewById(R.id.hobbies);
        ed3 = findViewById(R.id.address);
        btn1 = findViewById(R.id.male);
        btn2 = findViewById(R.id.female);

        String url = "http://192.168.43.85/hibbub/";
        retrofit = MyRetrofit.getRetrofit(url);
        apiInterface = retrofit.create(APIInterface.class);
    }

    public void next(View view) {
        Intent i = new Intent(this, AcheivementActivity.class);
        startActivity(i);
        finish();
    }

    public void submit(View view) {
        Call<String> c = apiInterface.submit();
        c.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {

            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Toast.makeText(PersonalProfile2.this,
                        "Do not Submit",
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}