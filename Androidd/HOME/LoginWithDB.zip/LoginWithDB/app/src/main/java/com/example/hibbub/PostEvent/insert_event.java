package com.example.hibbub.PostEvent;

public class insert_event {
    /*private static final String TAG = "mylog";
    APIService apiService2;
    apiService2.insert_event(@Query String t1,@Query String t2,@Query String t3,@Query String t4).enqueue(new Callback<String>() {
        @Override
        public void onResponse (Call < String > call, Response < String > response){
            Log.d(TAG, response.toString());
        }

        @Override
        public void onFailure (Call < String > call, Throwable t){
            Log.d(TAG, t.toString());
        }
    })*/
}
