package com.example.hibbub.PersonalProfile;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.hibbub.Home.HomeActivity;
import com.example.hibbub.PersonalProfile2.PersonalProfile2;
import com.example.hibbub.R;

import java.util.Calendar;

public class PersonalProfile extends AppCompatActivity implements Runnable {
    private static final int PICKFILE_RESULT_CODE = 1;
    EditText ed1, ed2, ed3, ed4, ed5;
    RadioButton fac, stu, adm, alu;
    ImageView iv;
    int manageid=0;
    ProgressDialog pd, pd1;
    private DatePicker dp;
    private Calendar cal;
    private int year, month, day;
    private TextView dw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_profile);
        ed1 = findViewById(R.id.ed1);
        ed2 = findViewById(R.id.ed2);
        ed3 = findViewById(R.id.ed3);
        ed4 = findViewById(R.id.contact1);
        ed5 = findViewById(R.id.contact2);
        fac = findViewById(R.id.faculty);
        alu = findViewById(R.id.alumni);
        adm = findViewById(R.id.admin);
        stu = findViewById(R.id.student);
        iv = findViewById(R.id.img1);
        dw = findViewById(R.id.date1);
        cal = Calendar.getInstance();
        year = cal.get(Calendar.YEAR);
        month = cal.get(Calendar.MONTH);
        day = cal.get(Calendar.DAY_OF_MONTH);

        displayFrags(R.id.perinfo,"PersonalProfile");

    }

    public void date(View view) {
        Calendar cl;
        cl = Calendar.getInstance();

        DatePickerDialog dpd;
        dpd = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                dw.setText(i2 + "/" + (i1 + 1) + "/" + i);
            }

        }, Calendar.YEAR, Calendar.MONTH, Calendar.DAY_OF_MONTH);
        dpd.setCancelable(false);

        dpd.show();
    }


    public void previous(View view) {
        Intent intent = new Intent(this, HomeActivity.class);
        startActivityForResult(intent, 200);
        finish();
    }

    public void next(View view) {
        Intent i = new Intent(this, PersonalProfile2.class);
        startActivity(i);
        finish();
    }


    public void attach1(View view) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("file/*");
        startActivityForResult(intent, PICKFILE_RESULT_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            /*case requestCode == 1:
                String name = ed1 +" "+ ed2 +" "+ ed3;
                break;*/
            case PICKFILE_RESULT_CODE:
                if (resultCode == RESULT_OK) {
                    String FilePath = data.getData().getPath();
                    iv.setImageResource(Integer.parseInt(FilePath));
                }
                break;
        }
    }

    public void displayFrags(int itemId,String itemTitle) {
        FragmentTransaction ft;
        FragmentManager fm;

        fm = getSupportFragmentManager();
        ft = fm.beginTransaction();
        Log.d("Whyred", itemTitle);

        switch(itemId)
        {
            case R.id.perinfo:
                if(manageid==R.id.perinfo)
                {
                    itemTitle="HUBBUB";
                    Log.d("Whyred","Not Changed");
                }
                else {
                    itemTitle="HUBBUB";
                    manageid=R.id.home;

                }
                break;
        }
    }

    public void progress2(View view) {

        pd = new ProgressDialog(this);
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        pd.setMessage("Uploading");
        pd.show();
        Handler h = new Handler();
        h.postDelayed(this, 3000);

    }

    public void onBackPressed() {
        Intent i = new Intent(this, HomeActivity.class);
        startActivityForResult(i, 1, null);
    }

    @Override
    public void run() {
        for (int i = 0; i <= 100; i++) {
            pd1.setProgress(i);
        }
    }
}