package com.example.hibbub.SignUp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.hibbub.Login.LoginActivity;
import com.example.hibbub.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class SignUpActivity extends AppCompatActivity {
    EditText ed1, ed2,ed3;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        ed1 = findViewById(R.id.email1);
        ed2 = findViewById(R.id.pwd);
        ed3 = findViewById(R.id.cpwd);

        mAuth = FirebaseAuth.getInstance();
    }

    public void submit(View view) {
        String email = ed1.getText().toString();
        String password = ed2.getText().toString();
        String cpassword = ed3.getText().toString();
        if (email.length() == 0) {
            ed1.setError("Email is not Entered");
            ed1.requestFocus(1);
        } else if (password.length() == 0) {
            ed2.setError("Password is not Entered");
            ed2.requestFocus(2);
        }else if (cpassword.length() == 0) {
            ed2.setError("Confirm Password is not Entered");
            ed2.requestFocus(2);
        } else if (password.equals(cpassword)) {
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {

                                Log.d("gilog", "createUserWithEmail:success");
                                Intent i = new Intent(SignUpActivity.this, LoginActivity.class);
                                startActivity(i);
                                finish();
                            } else {
                                // If sign in fails, display a message to the user.
                                Log.w("gilog", "createUserWithEmail:failure", task.getException());
                                Toast.makeText(SignUpActivity.this, "Authentication failed.",
                                        Toast.LENGTH_SHORT).show();

                            }
                        }
                    });

            /*String data = "a=" + email + "&b=" + password + "&c=" + cpassword;
            MyTask task = new MyTask(this, email);
            task.execute(data);
            Intent i = new Intent(SignUpActivity.this, LoginActivity.class);
            startActivity(i);
            finish();*/

        } else {
            Toast.makeText(this, "Password is not matched", Toast.LENGTH_SHORT).show();
        }
    }

    public void reset(View view) {
        ed1.setText("");
        ed2.setText("");

        ed1.requestFocus();
    }
}
