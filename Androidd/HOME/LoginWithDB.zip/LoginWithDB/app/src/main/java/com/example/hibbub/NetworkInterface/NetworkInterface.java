package com.example.hibbub.NetworkInterface;

public interface NetworkInterface {
    void response(String msg);
}

