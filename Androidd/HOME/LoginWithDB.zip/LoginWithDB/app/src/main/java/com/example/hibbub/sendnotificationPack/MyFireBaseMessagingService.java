package com.example.hibbub.sendnotificationPack;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.hibbub.Login.LoginActivity;
import com.example.hibbub.MySharedPre.MySharedPre;
import com.example.hibbub.R;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFireBaseMessagingService extends FirebaseMessagingService {

    public String TAG = "mylog";
    String title, message;
    String CHANNEL_ID = "my_notification";
    MySharedPre sharedPre;
    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "Refreshed token: " + token);
        sharedPre=new MySharedPre(getApplicationContext());
        sharedPre.writeData("fcm",token);
        /*APIService apiService1, apiService2;
        //apiService1 = Client_wamp.getClient("http://10.0.2.2/").create(APIService.class);
        //apiService2 = Client_wamp.getClient("http://10.0.2.2/").create(APIService.class);
        //apiService1 = Client_wamp.getClient().create(APIService.class);
        Retrofit retrofit = MyRetrofit.getRetrofit(getResources().getString(R.string.IP));
        apiService1=retrofit.create(APIService.class);
        apiService1.insertKey(token).enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                Log.d(TAG, response.toString());
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Log.d(TAG, t.toString());
            }
        })*/;

    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        title = remoteMessage.getData().get("Title");
        message = remoteMessage.getData().get("Message");
        notification();
    }

    void notification() {
        createNotificationChannel();

        Intent intent = new Intent(this, LoginActivity.class);

        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.notification_icon)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(404, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "my notification";
            String description = "general notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}
