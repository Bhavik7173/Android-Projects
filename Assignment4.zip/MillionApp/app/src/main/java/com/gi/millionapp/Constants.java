package com.gi.millionapp;

public class Constants {

    public static final boolean DEFAULT_MUSIC_SETTING = false;

    public static final String COINS = "Coins : ";
    public static final String CORRECT = "Correct : ";
    public static final String WRONG = "Wrong : ";
    public static final String TOTAL_QUES = "Toatal Ques : ";



}
