package com.gi.application2.staticfunction;

public class AppSetting {
    public static String homeTitle = "Home";
    public static String mcqTitle = "MCQ";
    public static int numbers = 5;
}
