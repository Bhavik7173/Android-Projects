package com.gi.application2.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gi.application2.R;
import com.gi.application2.adapter.HistoryAdapter;
import com.gi.application2.model.ResultPojo;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {

    FloatingActionButton fab, addquiz, addlogout;
    TextView logout, addquiz1;
    ArrayList<ResultPojo> listViewModels;
    HistoryAdapter adapter;
    RecyclerView recycleView;
    Boolean isAllFabsVisible;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        fab = findViewById(R.id.fab);
        addquiz = findViewById(R.id.quiz);
        addlogout = findViewById(R.id.logout_btn);
        logout = findViewById(R.id.logout);
        addquiz1 = findViewById(R.id.addquiz);

        addquiz.setVisibility(View.GONE);
        addlogout.setVisibility(View.GONE);
        logout.setVisibility(View.GONE);
        addquiz1.setVisibility(View.GONE);
        isAllFabsVisible = false;
        recycleView = findViewById(R.id.recycleView);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!isAllFabsVisible) {


                    addquiz.show();
                    addlogout.show();
                    logout.setVisibility(View.VISIBLE);
                    addquiz1.setVisibility(View.VISIBLE);

                    isAllFabsVisible = true;
                } else {


                    addquiz.hide();
                    addlogout.hide();
                    logout.setVisibility(View.GONE);
                    addquiz1.setVisibility(View.GONE);


                    isAllFabsVisible = false;
                }
            }
        });
        addlogout.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast.makeText(HistoryActivity.this, "Person Added", Toast.LENGTH_SHORT).show();
                    }
                });
        addquiz.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(HistoryActivity.this,RuleActivity.class);
                        startActivity(intent);
                    }
                });
        listViewModels = new ArrayList<>();
        adapter = new HistoryAdapter(HistoryActivity.this, listViewModels);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(HistoryActivity.this);
        recycleView.setLayoutManager(mLayoutManager);
        recycleView.setHasFixedSize(true);
        recycleView.setAdapter(adapter);
    }
}