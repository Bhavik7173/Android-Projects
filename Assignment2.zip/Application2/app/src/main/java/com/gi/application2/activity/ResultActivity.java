package com.gi.application2.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.gi.application2.R;
import com.gi.application2.model.QuestionPojo;
import com.gi.application2.model.ResultPojo;
import com.gi.application2.model.User;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;

public class ResultActivity extends AppCompatActivity {

    TextView result, setTitle, nonAttemptText, attemptText;
    String count, title, totalQuestion, nonAttempt, Attempt;
    Button viewResult;

    ArrayList<QuestionPojo> questionPojos;
    ArrayList<ResultPojo> resultPojos;
    User user = User.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
//        sharedPre.writeData("userID", user.getUser_id());
//        sharedPre.writeData("status", "LoggedIn");

        getSupportActionBar().setTitle(Html.fromHtml("<font color='#ffffff'>Result</font>"));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.back);
        questionPojos = getIntent().getParcelableArrayListExtra("list");
        result = findViewById(R.id.result);
        nonAttemptText = findViewById(R.id.nonAttemptText);
        attemptText = findViewById(R.id.attemptText);
        setTitle = findViewById(R.id.setTitle);
        viewResult = findViewById(R.id.viewResult);

        count = getIntent().getStringExtra("count");
        Log.d("gilog",count+"");

        title = getIntent().getStringExtra("title");
        Log.d("gilog",title+"");
        totalQuestion = getIntent().getStringExtra("totalQuestion");
        Log.d("gilog",totalQuestion+"");
        nonAttempt = getIntent().getStringExtra("nonAttempt");
        Log.d("gilog",nonAttempt+"");
        Attempt = Integer.parseInt(totalQuestion) - Integer.parseInt(nonAttempt) + "";
        Log.d("gilog",Attempt+"");

        result.setText(count + "/" + totalQuestion);
        setTitle.setText(title);
        nonAttemptText.setText(nonAttempt);
        attemptText.setText(Attempt);

//        resultPojos = new ArrayList<ResultPojo>();
//        resultPojos.add(new ResultPojo(totalQuestion,Attempt,nonAttempt));


        viewResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this, ViewSummary.class);
                intent.putExtra("title", title);
                intent.putParcelableArrayListExtra("list",questionPojos);
                startActivity(intent);
            }
        });
    }

//    public void getResultData(ArrayList<ResultPojo> resultArrayList) {
//        resultArrayList.add(new ResultPojo());
//        resultArrayList.add(new ResultPojo("2","Which country gifted the 'Statue of Liberty' to USA in 1886?","France","Canada","Brazil","England","A"));
//        resultArrayList.add(new ResultPojo("3","Dead Sea is located between which two countries?","Jordan And Sudan","Jordan And Israel","Turkey And UAE","UAE And Egypt","B"));
//        resultArrayList.add(new ResultPojo("4","Which country is known as the 'Land of Thanderbolts'?","China","Bhutan","Mongolia","Thailand","B"));
//        resultArrayList.add(new ResultPojo("5","Which plateau is known as the 'Roof of the world'?","Andes","Himalaya","Karakoram","Pamir","D"));
//
//    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(this, QuizActivity.class);
                startActivity(intent);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, QuizActivity.class);
        startActivity(intent);
    }
}