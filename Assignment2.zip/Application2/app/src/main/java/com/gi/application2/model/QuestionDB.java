package com.gi.application2.model;

import java.util.ArrayList;
import java.util.List;

public class QuestionDB {
    public static List<QuestionPojo> questionData = new ArrayList<>();
}
