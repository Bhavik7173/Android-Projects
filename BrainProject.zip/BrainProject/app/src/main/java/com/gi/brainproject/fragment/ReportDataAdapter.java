package com.gi.brainproject.fragment;

import android.content.Context;
import android.content.Intent;
import android.media.tv.TvContract;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.gi.brainproject.R;

import java.util.ArrayList;

public class ReportDataAdapter extends RecyclerView.Adapter<ReportDataAdapter.ViewHolder> {
    ArrayList<ReportData> data = new ArrayList<ReportData>();
    public static Context context;

    public ReportDataAdapter(Context context, ArrayList<ReportData> modelArrayList) {
        this.context = context;
        data = modelArrayList;
    }


    @NonNull
    @Override
    public ReportDataAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.layout_row_data, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ReportDataAdapter.ViewHolder holder, int position) {
        ReportData model = data.get(position);
        holder.t1.setText("Course: " + model.getName());
        holder.t2.setText("Course: " + model.getName());
        holder.i1.setImageDrawable(model.getImage());
        holder.i2.setImageDrawable(model.getImage());
//        holder.ll_cdesign.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(view.getContext(), "click on item: " + model.getCname(), Toast.LENGTH_LONG).show();
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener {
        ImageView i1,i2;
        TextView t1,t2;
        CardView c1,c2;
        public ViewHolder(View listItem) {
            super(listItem);

            i1 =listItem.findViewById(R.id.nImg);
            i2 =listItem.findViewById(R.id.nImg2);
            t1 =listItem.findViewById(R.id.nEdt);
            t2 =listItem.findViewById(R.id.nEdt2);
            listItem.setOnCreateContextMenuListener(this);
        }

        @Override
        public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {

        }
    }
}
