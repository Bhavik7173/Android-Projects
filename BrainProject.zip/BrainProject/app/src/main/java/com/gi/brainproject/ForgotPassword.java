package com.gi.brainproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotPassword extends AppCompatActivity {

    TextView submit;
    EditText npass, ncpass;
    String newpass, newcpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        npass = findViewById(R.id.newPass);
        ncpass = findViewById(R.id.confirmPass);
        submit = findViewById(R.id.submit);

        Intent intent = getIntent();
        String str = intent.getStringExtra("email");

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                newpass = npass.getText().toString();
                newcpass = ncpass.getText().toString();
                if (newpass.equals(newcpass)) {
                    RetrofitClient.getClient(ForgotPassword.this).create(RetroInterface.class).forgotpassword(str, newpass, newcpass).enqueue(new Callback<String>() {

                        @Override
                        public void onResponse(Call<String> call, Response<String> response) {
                            Toast.makeText(ForgotPassword.this, "Update Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(ForgotPassword.this, Login.class);
                            startActivity(intent);
                        }

                        @Override
                        public void onFailure(Call<String> call, Throwable t) {
                            Toast.makeText(ForgotPassword.this, t.toString(), Toast.LENGTH_SHORT).show();
                            Log.d("response_fail", t.toString());
                        }
                    });
                }
                else{
                    Toast.makeText(ForgotPassword.this,"Please check the Password",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}