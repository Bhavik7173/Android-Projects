package com.gi.brainproject;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.gi.brainproject.fragment.FileResponse;

import java.io.File;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChangePassword extends AppCompatActivity {
    EditText email;
    TextView submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.changepassword);

        email = findViewById(R.id.et_email);
        submit = findViewById(R.id.bt_forget);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uemail = email.getText().toString();
                RetrofitClient.getClient(ChangePassword.this).create(RetroInterface.class).checkEmail(uemail).enqueue(new Callback<FileResponse>(){

                    @Override
                    public void onResponse(Call<FileResponse> call, Response<FileResponse> response) {
                        Log.d("response_Change",response.body().toString());
                        if(response.body().getSuccess()=="true") {
                            Intent intent = new Intent(ChangePassword.this, ForgotPassword.class);
                            intent.putExtra("email", uemail);
                            startActivity(intent);
                        }
                        else
                        {
                            Log.d("response_change_failur",response.body().toString());
                        }
                    }

                    @Override
                    public void onFailure(Call<FileResponse> call, Throwable t) {
                        Log.d("response_fail",t.toString());
                    }
                });
            }
        });
    }
}
