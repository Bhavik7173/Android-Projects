package com.gi.brainproject;

import com.gi.brainproject.fragment.FileResponse;

import java.util.List;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface RetroInterface {

    @GET("/signup")
    Call<String> signup(@Query("name") String name,@Query("dob") String dob,@Query("mob") String mob,@Query("email") String email,@Query("pass") String pass);

    @GET("/login")
    Call<List<User>> login(@Query("email") String email);

    @Multipart
    @POST("upload")
    Call<FileResponse> upload(@Part MultipartBody.Part image);

    @GET("/checkemail")
    Call<FileResponse> checkEmail(@Query("uemail") String uemail);

    @GET("/forgotpassword")
    Call<String> forgotpassword(@Query("email") String str,@Query("newpass") String newpass,@Query("newcpass") String newcpass);

    @GET("/personal_detail")
    Call<List<User>> getPersonalDetail(@Query("email") String email);

    @GET("/update_detail")
    Call<FileResponse> updateDetail(@Query("name") String name,@Query("dob") String dob,@Query("mob") String mob,@Query("email") String email,@Query("pass") String pass);
}
