package com.gi.brainproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Login extends AppCompatActivity {

    EditText uname, password;
    TextView login, reset,register,forgotpassword;
    SharedPreferences pref, pref1;
    Intent intent, intent1;
    String pass, rname, rpass,email;
    List<User> myListData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        uname = findViewById(R.id.usernameEdt);
        password = findViewById(R.id.pass);
        login = findViewById(R.id.login);
        reset = findViewById(R.id.resetBtn);
        register = findViewById(R.id.Register);
        forgotpassword = findViewById(R.id.forgotpassword);
        pref = getSharedPreferences("user_details", MODE_PRIVATE);
        intent = new Intent(Login.this, BrainHome.class);
        if (pref.contains("username") && pref.contains("password")) {
            startActivity(intent);
        }
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uname.setText("");
                password.setText("");
            }
        });
        forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Login.this, ChangePassword.class);
                startActivity(i);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = uname.getText().toString();
                pass = password.getText().toString();

                RetrofitClient.getClient(Login.this).create(RetroInterface.class).login(email)
                        .enqueue(new Callback<List<User>>() {
                            @Override
                            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                                myListData = response.body();
                                Log.d("gilog", myListData + "");
                                for (int i = 0; i < myListData.size(); i++) {
                                    Log.d("gilog", myListData.get(i).getPassword() + "");
                                    Log.d("gilog", myListData.get(i).getEmail() + "");
                                    if (email.equals(myListData.get(i).getEmail()) && pass.equals(myListData.get(i).getPassword())) {
                                        SharedPreferences.Editor editor = pref.edit();
                                        editor.putString("username", myListData.get(i).getName());
                                        editor.putString("email", email);
                                        editor.putString("password", pass);
                                        editor.commit();
                                        Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();

                                        startActivity(intent);
                                    }
                                }

//
                            }

                            @Override
                            public void onFailure(Call<List<User>> call, Throwable t) {
                                Toast.makeText(Login.this, " " + t.getMessage(), Toast.LENGTH_SHORT).show();
                                Log.d("gisurat", t.toString());
                            }
                        });
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Login.this, Signup.class);
                startActivity(i);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity();
    }
}