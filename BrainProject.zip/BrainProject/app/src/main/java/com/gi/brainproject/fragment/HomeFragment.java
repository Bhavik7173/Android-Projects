package com.gi.brainproject.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gi.brainproject.R;

import java.util.ArrayList;


public class HomeFragment extends Fragment {
    FrameLayout frameLayout;

    Context context;
    RecyclerView recyclerView;
    ArrayList<ReportData> modelArrayList;
    ReportDataAdapter reportDataAdapter;
    public HomeFragment(Context context) {
        this.context = context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);
        frameLayout = view.findViewById(R.id.flFragment);
        recyclerView = view.findViewById(R.id.crev);
        modelArrayList = new ArrayList<>();
        reportDataAdapter = new ReportDataAdapter(context, modelArrayList);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context, RecyclerView.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(reportDataAdapter);
        return view;
    }

}