package com.gi.programing_quiz.db;

import com.gi.programing_quiz.Pojo.QuestionPojo;

import java.util.ArrayList;
import java.util.List;

public class QuestionDB {
    public static List<QuestionPojo> questionData = new ArrayList<>();
}

