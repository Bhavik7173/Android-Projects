package com.gi.programing_quiz.AppStaticClass;

public class Filter {
    public static String sal = new String();
    public static String exp = new String();

}
